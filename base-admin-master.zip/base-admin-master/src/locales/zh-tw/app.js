export default {
  name: "BASE",
};
