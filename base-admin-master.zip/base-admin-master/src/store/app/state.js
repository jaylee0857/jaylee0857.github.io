const state = () => {
  return {};
};

export default state;
