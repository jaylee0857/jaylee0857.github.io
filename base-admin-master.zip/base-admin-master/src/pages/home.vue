<template>
  <div>Hello!</div>
</template>

<script>
export default {
  name: "Home",
  setup() {
    return {};
  },
};
</script>
