<template>
  <div>
    layout
    <slot />
  </div>
</template>

<script>
export default {
  setup() {
    return {};
  },
};
</script>
